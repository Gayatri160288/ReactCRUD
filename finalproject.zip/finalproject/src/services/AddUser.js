import "./adduser.css"

import { useDispatch, useSelector } from "react-redux";

import { useNavigate} from "react-router-dom";
import { useState } from "react";
import { userAdded } from "./usersSlice";

export function AddUser() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState(null);

  const handleName = (e) => setName(e.target.value);
  const handleEmail = (e) => setEmail(e.target.value);

  const usersAmount = useSelector((state) => state.users.entities.length);

  const handleClick = () => {
    if (name && email) {
      dispatch(
        userAdded({
          id: usersAmount + 1,
          name,
          email,
        })
      );

      setError(null);
      navigate("/Dashboard");
    } else {
      setError("Fill in all fields");
    }

    setName("");
    setEmail("");
  };

  return (
    <div className="user-container">
      <div className="heading">
        <h1>Add user</h1>
      </div>
      <div className="row">
        <div className="three-columns">
         <div className="input-box"> 
         <label htmlFor="nameInput">Name:</label>
          <input
            className="u-full-width"
            type="text"
            placeholder="Enter Your Name"
            id="nameInput"
            onChange={handleName}
            value={name}
          />
         </div>
          <div className="input-box">
          <label htmlFor="emailInput">Email:</label>
          <input
            className="u-full-width"
            type="email"
            placeholder="test@mailbox.com"
            id="emailInput"
            onChange={handleEmail}
            value={email}
          />
          {error && error}
          </div>
          <div >
          <button onClick={handleClick} className="button-primary11">
            Add user
          </button>
          </div>
        </div>
      </div>
    </div>
  );
}
