import React from 'react'
import "./Navbar.css"
import { useNavigate } from 'react-router-dom'



const Navbar = () => {

  const navigate = useNavigate()
         const handleLogout = () => {
         localStorage.clear()
         navigate("/login")
     }

  return (
    <section className='Navbar'>
    <div className='navbar-container'>
      <div className='logo'>
          {/* <img src='' alt='/' /> */}
      </div>
      <div className='search-bar'>
          <input placeholder='search here'/>
      </div>
             <button className='logout-btn' onClick={handleLogout}>Log Out</button>
    </div>
  </section>
  )
}

export default Navbar
