import './App.css';
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import Login from './login/Login';
import AuthRoute from './AuthRoute/AuthRoute';
import MainLayout from './MainLayout/MainLayout';
import Dashboard from './Components/Dashboard';
import About from './Components/About';
import Home from './Home';
import { AddUser } from './services/AddUser';
import {EditUser }from './services/EditUser';


const router = createBrowserRouter([
  
  {
    path : "/login",
    element : <Login/>,
  },
  {
    path:"/",
    element:<AuthRoute><MainLayout/></AuthRoute>,
    children:[{
      path:"/",
      element:<Home/>,
    },
    {
      path:"/Dashboard",
      element:<Dashboard/>,
    },
    {
      path:"/add-user",
      element:<AddUser/>,
    },
    {
      path:"/edit-user/:id",
      element:<EditUser/>,
    },

  ]
  },
  {
    path:"/About",
    element:<About/>,
  },
  
  
]);

function App() {
  return (
    <div className="App">
      <RouterProvider router={router} />
    </div>
  );
}

export default App;
