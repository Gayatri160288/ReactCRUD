import React from 'react'
import { Outlet } from 'react-router-dom'
import "./MainLayout.css"
import { NavLink } from 'react-router-dom'
import Navbar from '../Navbar/Navbar'


const MainLayout = () => {


  return (
    <div>
      <header>
        <Navbar/>
      </header>
      <main className='main-layout'>
        <div className='sidebar'>
        <ul>
        <li className='active'>
            <NavLink to={"/"}>Home</NavLink>
        </li>
        <li>
            <NavLink to={"/About"} >About</NavLink>
        </li>
        <li>
            <NavLink to={"/Contact"}>Contact</NavLink>
        </li>
        <li>
            <NavLink to={"/Dashboard"} >Dashboard</NavLink>
        </li>
      </ul>
        </div>
        <div className='outlet'> 
           <Outlet/>
        </div>
      </main> 
    </div>
  )
}

export default MainLayout;
