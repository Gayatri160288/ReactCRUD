import React from 'react'
import { Outlet } from 'react-router-dom'
import "./MainLayout.css"
import { NavLink } from 'react-router-dom'
import Navbar from '../../common/Navbar/Navbar'


const MainLayout = () => {


  return (
    <div>
      <header>
        <Navbar />
      </header>
      <main className='main-layout'>
        <div className='sidebar'>
          <ul>
            <li>
              <NavLink to={"/add-user"}>
                Add User
              </NavLink>
            </li>
          </ul>
        </div>
        <div className='outlet'>
          <Outlet />
        </div>
      </main>
    </div>
  )
}

export default MainLayout;
