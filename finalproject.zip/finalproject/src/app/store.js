import { configureStore } from "@reduxjs/toolkit";
import usersReducer from "../services/usersSlice";

export default configureStore({
  reducer: {
    users: usersReducer,
  },
});
