
import './App.css';
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import Login from './Components/pages/login/Login';
import AuthRoute from './AuthRoute/AuthRoute';
import MainLayout from './Components/pages/MainLayout/MainLayout';
import Dashboard from './Components/pages/dashboard/Dashboard';
import { AddUser } from './Components/pages/Adduser/AddUser';
import {EditUser }from './Components/pages/editUser/EditUser';
import UserDetail from './Components/pages/userDetails/UserDetail';

const router = createBrowserRouter([
  
  {
    path : "/Login",
    element : <Login/>,
  },
  {
    path:"/",
    element:<AuthRoute><MainLayout/></AuthRoute>,
    children:[
    {
      path:"/",
      element:<Dashboard/>,
    },
    {
      path:"/add-user",
      element:<AddUser/>,
    },
    {
      path:"/edit-user/:id",
      element:<EditUser/>,
    },
    {
      path:"/user/:id",
      element:<UserDetail/>,
    },

  ]
  },
  
]);

function App() {
  return (
    <div className="App">
      <RouterProvider router={router} />
    </div>
  );
}

export default App;
