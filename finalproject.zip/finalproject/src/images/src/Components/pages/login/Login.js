import React, { useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import InputField from '../../common/inputField/InputField'
import "./Login.css"


const Login = () => {
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const navigate = useNavigate()
    const isUserLoggedIn = localStorage.getItem("isUser")
    const isLoggedIn = JSON.parse(isUserLoggedIn)

    const handleLogin = () => {

        if (email && password) {
            localStorage.setItem("isUser", true)
            navigate("/")
        } else {
            alert("Please enter your credentials!")
        }
        if (isLoggedIn) return <Navigate to={"/"}/>
    }

     
    return (
        <div class="form-page">
        <div class="form-container login">
         <form action="">
            <h1>Login</h1>
            <div class="input-group">
                <InputField className="input" type="email" name="username" onChange={(e)=>setEmail(e.target.value)} required/>
                <label>Email</label>
            </div>
            <div class="input-group">
            <InputField className="input" type="password" name="username" onChange={(e)=>setPassword(e.target.value)} required/>
              <label>Password</label>
          </div>
          <div class="checkbox-group">
              <label>
              <InputField className="input" type="checkbox" />
                  Remember me
              </label>
          </div>
          <button class="submit-btn" onClick={handleLogin} type="submit">Login</button>
          <div class="signup-link">
              <p>Don't have an account?
                  <a href="/" class="signup-btn">Sign Up</a>
              </p>
          </div>
         </form>
       </div>
    </div>
    )
}

export default Login