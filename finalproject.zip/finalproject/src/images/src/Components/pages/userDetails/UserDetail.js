import React from 'react'
import axios from "axios"
import { useState, useEffect } from 'react';
import { useParams} from 'react-router-dom'

const UserDetail = () => {
    const [user,setUser] = useState();
    
    useEffect(() => {
    axios.get(`https://jsonplaceholder.typicode.com/users/${id}`).then((res) =>{
        setUser(res.data)
    })
    }, [])
    const {id} = useParams();
 
  return (
    <div className='card-container'>
        {user && (
         <div className='user-card'>
         <div className='avatar'>
           {/* <img src={}/> */}
         </div>
         <div>
            <h3>{user.username}</h3>
         </div>
   </div>
     )}
      
    </div>
  )
}

export default UserDetail
