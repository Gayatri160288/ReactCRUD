import React from 'react'
import { Navigate } from 'react-router-dom'

const AuthRoute = ({children}) => {
  const isLoggedIn = localStorage.getItem("isUser")
  console.log("children",children)
 if(isLoggedIn) return <>{children}</>
 return <Navigate to="/login" />
}

export default AuthRoute;
