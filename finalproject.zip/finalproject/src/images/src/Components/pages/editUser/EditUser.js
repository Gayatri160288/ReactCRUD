import { NavLink } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useLocation } from "react-router-dom";
import { useState } from "react";
import { userUpdated } from "../../../redux/usersSlice";
import InputField from "../../common/inputField/InputField";
import Button from "../../common/button";
import "./edituser.css"

export function EditUser() {
  const { pathname } = useLocation();
  const userId = parseInt(pathname.replace("/edit-user/", ""));

  const user = useSelector((state) =>
    state.users.entities.find((user) => user.id === userId)
  );

  const dispatch = useDispatch();
  const Navigate = useNavigate();

  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [error, setError] = useState(null);

  const handleName = (e) => setName(e.target.value);
  const handleEmail = (e) => setEmail(e.target.value);

  const handleClick = () => {
    if (name && email) {
      dispatch(
        userUpdated({
          id: userId,
          name,
          email,
        })
      );

      setError(null);
      Navigate("/Dashboard");
    } else {
      setError("Fill in all fields");
    }
  };

  return (
    <div className="wrapper">
      <div className="edit_user_form">
        <h1>Edit user</h1>
      <form>
        <div className="input-field">
          <label htmlFor="nameInput">User Name:</label>
          <InputField className="input" type="text" id="nameInput" value={name} onChange={handleName} />
        </div>
        <div className="input-field">
          <label htmlFor="emailInput">Email</label>
          <InputField className="input" type="email" id="emailInput" value={email} onChange={handleEmail} />
          {error && error}
        </div>
        <div>
        <Button className="Edit-btn" onClick={handleClick} text="Update User" />
        <NavLink to={"/"}>
                <Button className="add-btn" text="Back"/>
             </NavLink>
        </div>
      </form>
      </div>
    </div>
  );
}
