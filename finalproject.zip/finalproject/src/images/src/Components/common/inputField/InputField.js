import React from 'react'

const InputField = ({className,placeholder,type,name,onChange}) => {
  return (
    <input className={className} placeholder={placeholder} type={type} name={name} onChange={onChange}/>
  )
}

export default InputField
