import { fetchUsers, userDeleted } from "../../../redux/usersSlice";
import { useDispatch, useSelector } from "react-redux";
import "./dashboard.css"
import { NavLink } from "react-router-dom";
import Button from "../../common/button";

export default function Dashboard() {
  const dispatch = useDispatch();

  const { entities } = useSelector((state) => state.users);
  const loading = useSelector((state) => state.loading);

  const handleDelete = (id) => {
    dispatch(userDeleted({ id }));
  };

  return (
    <div className="container">
      <div className="data-table">
        <h1>EMPLOYEES</h1>
        <hr/>
        <div>
          <Button className="Fetch_btn" onClick={() => dispatch(fetchUsers())} text="Fetch users" />
        </div>
        <div className="row">
          {loading ? (
            "Loading..."
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {entities.length &&
                  entities.map(({ id,name,phone, email }, i) => (
                    <tr key={i}>
                      <td>{id}</td>
                      <td>{name}</td>
                      <td>{email}</td>
                      <td>{phone}</td>
                      <td>
                      <NavLink to={`/user/${id}`}>
                          <Button className="View-btn" text="View" />
                        </NavLink>
                        <Button className="delete-btn" onClick={() => handleDelete(id)} text="Delete" />
                        <NavLink to={`/edit-user/${id}`}>
                          <Button className="edit-btn" text="Edit User" />
                        </NavLink>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
