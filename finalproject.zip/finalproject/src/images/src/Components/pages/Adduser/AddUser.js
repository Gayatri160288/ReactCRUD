import { useDispatch, useSelector } from "react-redux";
import { NavLink } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { userAdded } from "../../../redux/usersSlice";
import InputField from "../../common/inputField/InputField";
import Button from "../../common/button";
import "./adduser.css"

export function AddUser() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState(null);

  const handleName = (e) => setName(e.target.value);
  const handleEmail = (e) => setEmail(e.target.value);

  const usersAmount = useSelector((state) => state.users.entities.length);

  const handleClick = () => {
    if (name && email) {
      dispatch(
        userAdded({
          id: usersAmount + 1,
          name,
          email,
        })
      );

      setError(null);
      navigate("/");
    } else {
      setError("Fill in all fields");
    }

    setName("");
    setEmail("");
  };

  return (
    <div className="wrapper">
      <div className="add_user-form">
        <h1>Add user</h1>
      <form>
        <div className="input-field">
        <label>User Name:</label>
          <InputField className="input" placeholder="Please Enter Your Name" type="text" id="nameInput" value={name} onChange={handleName} />
        </div>
        <div className="input-field">
        <label>Email:</label>
          <InputField className="input" placeholder="Please Enter Your Email" type="text" id="emailInput" value={email} onChange={handleEmail} />
          {error && error}
        </div>
        <div >
          <Button className="add-btn" onClick={handleClick} text="Add User" />
             <NavLink to={"/"}>
                <Button className="add-btn" text="Back"/>
             </NavLink>
        </div>
      </form>
      </div>
    </div>
  );
}
