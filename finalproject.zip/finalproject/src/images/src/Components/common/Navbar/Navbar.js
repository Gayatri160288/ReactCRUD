import React from 'react'
import "./Navbar.css"
import { useNavigate } from 'react-router-dom'
import Button from '../button'



const Navbar = () => {

  const navigate = useNavigate()
  const handleLogout = () => {
    localStorage.clear()
    navigate("/login")
  }

  return (
    <section className='Navbar'>
      <div className='navbar-container'>
        <div className='logo'>
          <h1>
            <span>L</span>ogo
          </h1>
        </div>
        <Button className='logout-btn' onClick={handleLogout} text="Log Out" />
      </div>
    </section>
  )
}

export default Navbar
