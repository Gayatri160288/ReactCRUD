import React, { useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import "./Login.css"


const Login = () => {
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const navigate = useNavigate()
    const isUserLoggedIn = localStorage.getItem("isUser")
    const isLoggedIn = JSON.parse(isUserLoggedIn)

    const handleLogin = () => {

        if (email && password) {
            alert("Logged In")
            localStorage.setItem("isUser", true)
            navigate("/")
        } else {
            alert("Please enter your credentials!")
        }
        if (isLoggedIn) return <Navigate to={"/"}/>
    }

     
    return (
      <div className='form-main'>
          <div className='loginform' id="loginform">
            <h1 id="headerTitle">Login</h1>
            <div className="row">
                <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder='Email' />
            </div>
            <div className="row">
                <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder='Password' />
            </div>
            <div id="button" className="row">
                <button className="submit-btn" onClick={handleLogin}>Submit</button>
                </div>
        </div>
      </div>
    )
}

export default Login